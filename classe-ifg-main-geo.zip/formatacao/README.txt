Esta pasta contém arquivos para formatação do documento.

NÃO EDITE OU REMOVA NENHUM ARQUIVO DESTA PASTA!!!